/**
 */
package org.rm2pt.sample.libray.metamodel.libray;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Members</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.Members#getMemberId <em>Member Id</em>}</li>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.Members#getName <em>Name</em>}</li>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.Members#getDriverId <em>Driver Id</em>}</li>
 * </ul>
 *
 * @see org.rm2pt.sample.libray.metamodel.libray.LibrayPackage#getMembers()
 * @model
 * @generated
 */
public interface Members extends Membership {

	/**
	 * Returns the value of the '<em><b>Member Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Member Id</em>' attribute.
	 * @see #setMemberId(int)
	 * @see org.rm2pt.sample.libray.metamodel.libray.LibrayPackage#getMembers_MemberId()
	 * @model
	 * @generated
	 */
	int getMemberId();

	/**
	 * Sets the value of the '{@link org.rm2pt.sample.libray.metamodel.libray.Members#getMemberId <em>Member Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Member Id</em>' attribute.
	 * @see #getMemberId()
	 * @generated
	 */
	void setMemberId(int value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see org.rm2pt.sample.libray.metamodel.libray.LibrayPackage#getMembers_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link org.rm2pt.sample.libray.metamodel.libray.Members#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Driver Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Driver Id</em>' attribute.
	 * @see #setDriverId(int)
	 * @see org.rm2pt.sample.libray.metamodel.libray.LibrayPackage#getMembers_DriverId()
	 * @model
	 * @generated
	 */
	int getDriverId();

	/**
	 * Sets the value of the '{@link org.rm2pt.sample.libray.metamodel.libray.Members#getDriverId <em>Driver Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Driver Id</em>' attribute.
	 * @see #getDriverId()
	 * @generated
	 */
	void setDriverId(int value);
} // Members
