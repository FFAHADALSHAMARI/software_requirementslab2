/**
 */
package org.rm2pt.sample.libray.metamodel.libray.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.rm2pt.sample.libray.metamodel.libray.LibrayPackage;
import org.rm2pt.sample.libray.metamodel.libray.Members;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Members</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.impl.MembersImpl#getMemberId <em>Member Id</em>}</li>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.impl.MembersImpl#getName <em>Name</em>}</li>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.impl.MembersImpl#getDriverId <em>Driver Id</em>}</li>
 * </ul>
 *
 * @generated
 */
public class MembersImpl extends MembershipImpl implements Members {
	/**
	 * The default value of the '{@link #getMemberId() <em>Member Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMemberId()
	 * @generated
	 * @ordered
	 */
	protected static final int MEMBER_ID_EDEFAULT = 0;
	/**
	 * The cached value of the '{@link #getMemberId() <em>Member Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMemberId()
	 * @generated
	 * @ordered
	 */
	protected int memberId = MEMBER_ID_EDEFAULT;
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;
	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;
	/**
	 * The default value of the '{@link #getDriverId() <em>Driver Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDriverId()
	 * @generated
	 * @ordered
	 */
	protected static final int DRIVER_ID_EDEFAULT = 0;
	/**
	 * The cached value of the '{@link #getDriverId() <em>Driver Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDriverId()
	 * @generated
	 * @ordered
	 */
	protected int driverId = DRIVER_ID_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MembersImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return LibrayPackage.Literals.MEMBERS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getMemberId() {
		return memberId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMemberId(int newMemberId) {
		int oldMemberId = memberId;
		memberId = newMemberId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LibrayPackage.MEMBERS__MEMBER_ID, oldMemberId,
					memberId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LibrayPackage.MEMBERS__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getDriverId() {
		return driverId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDriverId(int newDriverId) {
		int oldDriverId = driverId;
		driverId = newDriverId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LibrayPackage.MEMBERS__DRIVER_ID, oldDriverId,
					driverId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case LibrayPackage.MEMBERS__MEMBER_ID:
			return getMemberId();
		case LibrayPackage.MEMBERS__NAME:
			return getName();
		case LibrayPackage.MEMBERS__DRIVER_ID:
			return getDriverId();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case LibrayPackage.MEMBERS__MEMBER_ID:
			setMemberId((Integer) newValue);
			return;
		case LibrayPackage.MEMBERS__NAME:
			setName((String) newValue);
			return;
		case LibrayPackage.MEMBERS__DRIVER_ID:
			setDriverId((Integer) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case LibrayPackage.MEMBERS__MEMBER_ID:
			setMemberId(MEMBER_ID_EDEFAULT);
			return;
		case LibrayPackage.MEMBERS__NAME:
			setName(NAME_EDEFAULT);
			return;
		case LibrayPackage.MEMBERS__DRIVER_ID:
			setDriverId(DRIVER_ID_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case LibrayPackage.MEMBERS__MEMBER_ID:
			return memberId != MEMBER_ID_EDEFAULT;
		case LibrayPackage.MEMBERS__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case LibrayPackage.MEMBERS__DRIVER_ID:
			return driverId != DRIVER_ID_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (memberId: ");
		result.append(memberId);
		result.append(", name: ");
		result.append(name);
		result.append(", driverId: ");
		result.append(driverId);
		result.append(')');
		return result.toString();
	}

} //MembersImpl
