/**
 */
package org.rm2pt.sample.libray.metamodel.libray;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see org.rm2pt.sample.libray.metamodel.libray.LibrayFactory
 * @model kind="package"
 * @generated
 */
public interface LibrayPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "libray";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.rm2pt.com/libray";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "libray";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	LibrayPackage eINSTANCE = org.rm2pt.sample.libray.metamodel.libray.impl.LibrayPackageImpl.init();

	/**
	 * The meta object id for the '{@link org.rm2pt.sample.libray.metamodel.libray.impl.LibraryImpl <em>Library</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.sample.libray.metamodel.libray.impl.LibraryImpl
	 * @see org.rm2pt.sample.libray.metamodel.libray.impl.LibrayPackageImpl#getLibrary()
	 * @generated
	 */
	int LIBRARY = 0;

	/**
	 * The feature id for the '<em><b>Students</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIBRARY__STUDENTS = 0;

	/**
	 * The feature id for the '<em><b>Membership</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIBRARY__MEMBERSHIP = 1;

	/**
	 * The feature id for the '<em><b>Borrowableitem</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIBRARY__BORROWABLEITEM = 2;

	/**
	 * The feature id for the '<em><b>Librarian</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIBRARY__LIBRARIAN = 3;

	/**
	 * The feature id for the '<em><b>Administrator</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIBRARY__ADMINISTRATOR = 4;

	/**
	 * The number of structural features of the '<em>Library</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIBRARY_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>Library</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIBRARY_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.rm2pt.sample.libray.metamodel.libray.impl.MembershipImpl <em>Membership</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.sample.libray.metamodel.libray.impl.MembershipImpl
	 * @see org.rm2pt.sample.libray.metamodel.libray.impl.LibrayPackageImpl#getMembership()
	 * @generated
	 */
	int MEMBERSHIP = 1;

	/**
	 * The feature id for the '<em><b>Bannedmembers</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEMBERSHIP__BANNEDMEMBERS = 0;

	/**
	 * The feature id for the '<em><b>Membershib Status</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEMBERSHIP__MEMBERSHIB_STATUS = 1;

	/**
	 * The number of structural features of the '<em>Membership</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEMBERSHIP_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Membership</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEMBERSHIP_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.rm2pt.sample.libray.metamodel.libray.impl.ItemImpl <em>Item</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.sample.libray.metamodel.libray.impl.ItemImpl
	 * @see org.rm2pt.sample.libray.metamodel.libray.impl.LibrayPackageImpl#getItem()
	 * @generated
	 */
	int ITEM = 2;

	/**
	 * The feature id for the '<em><b>Booksavailable</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ITEM__BOOKSAVAILABLE = 0;

	/**
	 * The feature id for the '<em><b>Magazines Availble</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ITEM__MAGAZINES_AVAILBLE = 1;

	/**
	 * The number of structural features of the '<em>Item</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ITEM_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Item</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ITEM_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.rm2pt.sample.libray.metamodel.libray.impl.BannedItemsImpl <em>Banned Items</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.sample.libray.metamodel.libray.impl.BannedItemsImpl
	 * @see org.rm2pt.sample.libray.metamodel.libray.impl.LibrayPackageImpl#getBannedItems()
	 * @generated
	 */
	int BANNED_ITEMS = 3;

	/**
	 * The feature id for the '<em><b>Booksavailable</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BANNED_ITEMS__BOOKSAVAILABLE = ITEM__BOOKSAVAILABLE;

	/**
	 * The feature id for the '<em><b>Magazines Availble</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BANNED_ITEMS__MAGAZINES_AVAILBLE = ITEM__MAGAZINES_AVAILBLE;

	/**
	 * The feature id for the '<em><b>Ban Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BANNED_ITEMS__BAN_DATE = ITEM_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Reason</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BANNED_ITEMS__REASON = ITEM_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Banned Items</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BANNED_ITEMS_FEATURE_COUNT = ITEM_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Banned Items</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BANNED_ITEMS_OPERATION_COUNT = ITEM_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.rm2pt.sample.libray.metamodel.libray.impl.MagazinesImpl <em>Magazines</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.sample.libray.metamodel.libray.impl.MagazinesImpl
	 * @see org.rm2pt.sample.libray.metamodel.libray.impl.LibrayPackageImpl#getMagazines()
	 * @generated
	 */
	int MAGAZINES = 7;

	/**
	 * The meta object id for the '{@link org.rm2pt.sample.libray.metamodel.libray.impl.booksImpl <em>books</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.sample.libray.metamodel.libray.impl.booksImpl
	 * @see org.rm2pt.sample.libray.metamodel.libray.impl.LibrayPackageImpl#getbooks()
	 * @generated
	 */
	int BOOKS = 4;

	/**
	 * The feature id for the '<em><b>Booksavailable</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BOOKS__BOOKSAVAILABLE = ITEM__BOOKSAVAILABLE;

	/**
	 * The feature id for the '<em><b>Magazines Availble</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BOOKS__MAGAZINES_AVAILBLE = ITEM__MAGAZINES_AVAILBLE;

	/**
	 * The feature id for the '<em><b>Isbn</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BOOKS__ISBN = ITEM_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Author</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BOOKS__AUTHOR = ITEM_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Genre</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BOOKS__GENRE = ITEM_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Publish Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BOOKS__PUBLISH_DATE = ITEM_FEATURE_COUNT + 3;

	/**
	 * The number of structural features of the '<em>books</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BOOKS_FEATURE_COUNT = ITEM_FEATURE_COUNT + 4;

	/**
	 * The number of operations of the '<em>books</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BOOKS_OPERATION_COUNT = ITEM_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.rm2pt.sample.libray.metamodel.libray.impl.MembersImpl <em>Members</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.sample.libray.metamodel.libray.impl.MembersImpl
	 * @see org.rm2pt.sample.libray.metamodel.libray.impl.LibrayPackageImpl#getMembers()
	 * @generated
	 */
	int MEMBERS = 5;

	/**
	 * The feature id for the '<em><b>Bannedmembers</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEMBERS__BANNEDMEMBERS = MEMBERSHIP__BANNEDMEMBERS;

	/**
	 * The feature id for the '<em><b>Membershib Status</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEMBERS__MEMBERSHIB_STATUS = MEMBERSHIP__MEMBERSHIB_STATUS;

	/**
	 * The feature id for the '<em><b>Member Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEMBERS__MEMBER_ID = MEMBERSHIP_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEMBERS__NAME = MEMBERSHIP_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Driver Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEMBERS__DRIVER_ID = MEMBERSHIP_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Members</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEMBERS_FEATURE_COUNT = MEMBERSHIP_FEATURE_COUNT + 3;

	/**
	 * The number of operations of the '<em>Members</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEMBERS_OPERATION_COUNT = MEMBERSHIP_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.rm2pt.sample.libray.metamodel.libray.impl.ItemsModelImpl <em>Items Model</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.sample.libray.metamodel.libray.impl.ItemsModelImpl
	 * @see org.rm2pt.sample.libray.metamodel.libray.impl.LibrayPackageImpl#getItemsModel()
	 * @generated
	 */
	int ITEMS_MODEL = 6;

	/**
	 * The feature id for the '<em><b>Library</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ITEMS_MODEL__LIBRARY = 0;

	/**
	 * The feature id for the '<em><b>Item</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ITEMS_MODEL__ITEM = 1;

	/**
	 * The feature id for the '<em><b>Membership</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ITEMS_MODEL__MEMBERSHIP = 2;

	/**
	 * The number of structural features of the '<em>Items Model</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ITEMS_MODEL_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Items Model</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ITEMS_MODEL_OPERATION_COUNT = 0;

	/**
	 * The feature id for the '<em><b>Booksavailable</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAGAZINES__BOOKSAVAILABLE = ITEM__BOOKSAVAILABLE;

	/**
	 * The feature id for the '<em><b>Magazines Availble</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAGAZINES__MAGAZINES_AVAILBLE = ITEM__MAGAZINES_AVAILBLE;

	/**
	 * The feature id for the '<em><b>Title</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAGAZINES__TITLE = ITEM_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Issue Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAGAZINES__ISSUE_DATE = ITEM_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Magazines</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAGAZINES_FEATURE_COUNT = ITEM_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Magazines</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAGAZINES_OPERATION_COUNT = ITEM_OPERATION_COUNT + 0;

	/**
	 * Returns the meta object for class '{@link org.rm2pt.sample.libray.metamodel.libray.Library <em>Library</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Library</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.Library
	 * @generated
	 */
	EClass getLibrary();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.sample.libray.metamodel.libray.Library#getStudents <em>Students</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Students</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.Library#getStudents()
	 * @see #getLibrary()
	 * @generated
	 */
	EAttribute getLibrary_Students();

	/**
	 * Returns the meta object for the containment reference list '{@link org.rm2pt.sample.libray.metamodel.libray.Library#getMembership <em>Membership</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Membership</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.Library#getMembership()
	 * @see #getLibrary()
	 * @generated
	 */
	EReference getLibrary_Membership();

	/**
	 * Returns the meta object for the containment reference list '{@link org.rm2pt.sample.libray.metamodel.libray.Library#getBorrowableitem <em>Borrowableitem</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Borrowableitem</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.Library#getBorrowableitem()
	 * @see #getLibrary()
	 * @generated
	 */
	EReference getLibrary_Borrowableitem();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.sample.libray.metamodel.libray.Library#getLibrarian <em>Librarian</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Librarian</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.Library#getLibrarian()
	 * @see #getLibrary()
	 * @generated
	 */
	EAttribute getLibrary_Librarian();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.sample.libray.metamodel.libray.Library#getAdministrator <em>Administrator</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Administrator</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.Library#getAdministrator()
	 * @see #getLibrary()
	 * @generated
	 */
	EAttribute getLibrary_Administrator();

	/**
	 * Returns the meta object for class '{@link org.rm2pt.sample.libray.metamodel.libray.Membership <em>Membership</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Membership</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.Membership
	 * @generated
	 */
	EClass getMembership();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.sample.libray.metamodel.libray.Membership#getBannedmembers <em>Bannedmembers</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Bannedmembers</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.Membership#getBannedmembers()
	 * @see #getMembership()
	 * @generated
	 */
	EAttribute getMembership_Bannedmembers();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.sample.libray.metamodel.libray.Membership#isMembershibStatus <em>Membershib Status</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Membershib Status</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.Membership#isMembershibStatus()
	 * @see #getMembership()
	 * @generated
	 */
	EAttribute getMembership_MembershibStatus();

	/**
	 * Returns the meta object for class '{@link org.rm2pt.sample.libray.metamodel.libray.Item <em>Item</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Item</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.Item
	 * @generated
	 */
	EClass getItem();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.sample.libray.metamodel.libray.Item#getBooksavailable <em>Booksavailable</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Booksavailable</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.Item#getBooksavailable()
	 * @see #getItem()
	 * @generated
	 */
	EAttribute getItem_Booksavailable();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.sample.libray.metamodel.libray.Item#getMagazinesAvailble <em>Magazines Availble</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Magazines Availble</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.Item#getMagazinesAvailble()
	 * @see #getItem()
	 * @generated
	 */
	EAttribute getItem_MagazinesAvailble();

	/**
	 * Returns the meta object for class '{@link org.rm2pt.sample.libray.metamodel.libray.BannedItems <em>Banned Items</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Banned Items</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.BannedItems
	 * @generated
	 */
	EClass getBannedItems();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.sample.libray.metamodel.libray.BannedItems#getBanDate <em>Ban Date</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Ban Date</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.BannedItems#getBanDate()
	 * @see #getBannedItems()
	 * @generated
	 */
	EAttribute getBannedItems_BanDate();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.sample.libray.metamodel.libray.BannedItems#getReason <em>Reason</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Reason</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.BannedItems#getReason()
	 * @see #getBannedItems()
	 * @generated
	 */
	EAttribute getBannedItems_Reason();

	/**
	 * Returns the meta object for class '{@link org.rm2pt.sample.libray.metamodel.libray.Magazines <em>Magazines</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Magazines</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.Magazines
	 * @generated
	 */
	EClass getMagazines();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.sample.libray.metamodel.libray.Magazines#getTitle <em>Title</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Title</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.Magazines#getTitle()
	 * @see #getMagazines()
	 * @generated
	 */
	EAttribute getMagazines_Title();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.sample.libray.metamodel.libray.Magazines#getIssueDate <em>Issue Date</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Issue Date</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.Magazines#getIssueDate()
	 * @see #getMagazines()
	 * @generated
	 */
	EAttribute getMagazines_IssueDate();

	/**
	 * Returns the meta object for class '{@link org.rm2pt.sample.libray.metamodel.libray.books <em>books</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>books</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.books
	 * @generated
	 */
	EClass getbooks();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.sample.libray.metamodel.libray.books#getIsbn <em>Isbn</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Isbn</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.books#getIsbn()
	 * @see #getbooks()
	 * @generated
	 */
	EAttribute getbooks_Isbn();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.sample.libray.metamodel.libray.books#getAuthor <em>Author</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Author</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.books#getAuthor()
	 * @see #getbooks()
	 * @generated
	 */
	EAttribute getbooks_Author();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.sample.libray.metamodel.libray.books#getGenre <em>Genre</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Genre</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.books#getGenre()
	 * @see #getbooks()
	 * @generated
	 */
	EAttribute getbooks_Genre();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.sample.libray.metamodel.libray.books#getPublishDate <em>Publish Date</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Publish Date</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.books#getPublishDate()
	 * @see #getbooks()
	 * @generated
	 */
	EAttribute getbooks_PublishDate();

	/**
	 * Returns the meta object for class '{@link org.rm2pt.sample.libray.metamodel.libray.Members <em>Members</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Members</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.Members
	 * @generated
	 */
	EClass getMembers();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.sample.libray.metamodel.libray.Members#getMemberId <em>Member Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Member Id</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.Members#getMemberId()
	 * @see #getMembers()
	 * @generated
	 */
	EAttribute getMembers_MemberId();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.sample.libray.metamodel.libray.Members#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.Members#getName()
	 * @see #getMembers()
	 * @generated
	 */
	EAttribute getMembers_Name();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.sample.libray.metamodel.libray.Members#getDriverId <em>Driver Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Driver Id</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.Members#getDriverId()
	 * @see #getMembers()
	 * @generated
	 */
	EAttribute getMembers_DriverId();

	/**
	 * Returns the meta object for class '{@link org.rm2pt.sample.libray.metamodel.libray.ItemsModel <em>Items Model</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Items Model</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.ItemsModel
	 * @generated
	 */
	EClass getItemsModel();

	/**
	 * Returns the meta object for the containment reference list '{@link org.rm2pt.sample.libray.metamodel.libray.ItemsModel#getLibrary <em>Library</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Library</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.ItemsModel#getLibrary()
	 * @see #getItemsModel()
	 * @generated
	 */
	EReference getItemsModel_Library();

	/**
	 * Returns the meta object for the containment reference list '{@link org.rm2pt.sample.libray.metamodel.libray.ItemsModel#getItem <em>Item</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Item</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.ItemsModel#getItem()
	 * @see #getItemsModel()
	 * @generated
	 */
	EReference getItemsModel_Item();

	/**
	 * Returns the meta object for the containment reference list '{@link org.rm2pt.sample.libray.metamodel.libray.ItemsModel#getMembership <em>Membership</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Membership</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.ItemsModel#getMembership()
	 * @see #getItemsModel()
	 * @generated
	 */
	EReference getItemsModel_Membership();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	LibrayFactory getLibrayFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link org.rm2pt.sample.libray.metamodel.libray.impl.LibraryImpl <em>Library</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.sample.libray.metamodel.libray.impl.LibraryImpl
		 * @see org.rm2pt.sample.libray.metamodel.libray.impl.LibrayPackageImpl#getLibrary()
		 * @generated
		 */
		EClass LIBRARY = eINSTANCE.getLibrary();

		/**
		 * The meta object literal for the '<em><b>Students</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LIBRARY__STUDENTS = eINSTANCE.getLibrary_Students();

		/**
		 * The meta object literal for the '<em><b>Membership</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference LIBRARY__MEMBERSHIP = eINSTANCE.getLibrary_Membership();

		/**
		 * The meta object literal for the '<em><b>Borrowableitem</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference LIBRARY__BORROWABLEITEM = eINSTANCE.getLibrary_Borrowableitem();

		/**
		 * The meta object literal for the '<em><b>Librarian</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LIBRARY__LIBRARIAN = eINSTANCE.getLibrary_Librarian();

		/**
		 * The meta object literal for the '<em><b>Administrator</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LIBRARY__ADMINISTRATOR = eINSTANCE.getLibrary_Administrator();

		/**
		 * The meta object literal for the '{@link org.rm2pt.sample.libray.metamodel.libray.impl.MembershipImpl <em>Membership</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.sample.libray.metamodel.libray.impl.MembershipImpl
		 * @see org.rm2pt.sample.libray.metamodel.libray.impl.LibrayPackageImpl#getMembership()
		 * @generated
		 */
		EClass MEMBERSHIP = eINSTANCE.getMembership();

		/**
		 * The meta object literal for the '<em><b>Bannedmembers</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MEMBERSHIP__BANNEDMEMBERS = eINSTANCE.getMembership_Bannedmembers();

		/**
		 * The meta object literal for the '<em><b>Membershib Status</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MEMBERSHIP__MEMBERSHIB_STATUS = eINSTANCE.getMembership_MembershibStatus();

		/**
		 * The meta object literal for the '{@link org.rm2pt.sample.libray.metamodel.libray.impl.ItemImpl <em>Item</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.sample.libray.metamodel.libray.impl.ItemImpl
		 * @see org.rm2pt.sample.libray.metamodel.libray.impl.LibrayPackageImpl#getItem()
		 * @generated
		 */
		EClass ITEM = eINSTANCE.getItem();

		/**
		 * The meta object literal for the '<em><b>Booksavailable</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ITEM__BOOKSAVAILABLE = eINSTANCE.getItem_Booksavailable();

		/**
		 * The meta object literal for the '<em><b>Magazines Availble</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ITEM__MAGAZINES_AVAILBLE = eINSTANCE.getItem_MagazinesAvailble();

		/**
		 * The meta object literal for the '{@link org.rm2pt.sample.libray.metamodel.libray.impl.BannedItemsImpl <em>Banned Items</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.sample.libray.metamodel.libray.impl.BannedItemsImpl
		 * @see org.rm2pt.sample.libray.metamodel.libray.impl.LibrayPackageImpl#getBannedItems()
		 * @generated
		 */
		EClass BANNED_ITEMS = eINSTANCE.getBannedItems();

		/**
		 * The meta object literal for the '<em><b>Ban Date</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BANNED_ITEMS__BAN_DATE = eINSTANCE.getBannedItems_BanDate();

		/**
		 * The meta object literal for the '<em><b>Reason</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BANNED_ITEMS__REASON = eINSTANCE.getBannedItems_Reason();

		/**
		 * The meta object literal for the '{@link org.rm2pt.sample.libray.metamodel.libray.impl.MagazinesImpl <em>Magazines</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.sample.libray.metamodel.libray.impl.MagazinesImpl
		 * @see org.rm2pt.sample.libray.metamodel.libray.impl.LibrayPackageImpl#getMagazines()
		 * @generated
		 */
		EClass MAGAZINES = eINSTANCE.getMagazines();

		/**
		 * The meta object literal for the '<em><b>Title</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MAGAZINES__TITLE = eINSTANCE.getMagazines_Title();

		/**
		 * The meta object literal for the '<em><b>Issue Date</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MAGAZINES__ISSUE_DATE = eINSTANCE.getMagazines_IssueDate();

		/**
		 * The meta object literal for the '{@link org.rm2pt.sample.libray.metamodel.libray.impl.booksImpl <em>books</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.sample.libray.metamodel.libray.impl.booksImpl
		 * @see org.rm2pt.sample.libray.metamodel.libray.impl.LibrayPackageImpl#getbooks()
		 * @generated
		 */
		EClass BOOKS = eINSTANCE.getbooks();

		/**
		 * The meta object literal for the '<em><b>Isbn</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BOOKS__ISBN = eINSTANCE.getbooks_Isbn();

		/**
		 * The meta object literal for the '<em><b>Author</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BOOKS__AUTHOR = eINSTANCE.getbooks_Author();

		/**
		 * The meta object literal for the '<em><b>Genre</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BOOKS__GENRE = eINSTANCE.getbooks_Genre();

		/**
		 * The meta object literal for the '<em><b>Publish Date</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BOOKS__PUBLISH_DATE = eINSTANCE.getbooks_PublishDate();

		/**
		 * The meta object literal for the '{@link org.rm2pt.sample.libray.metamodel.libray.impl.MembersImpl <em>Members</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.sample.libray.metamodel.libray.impl.MembersImpl
		 * @see org.rm2pt.sample.libray.metamodel.libray.impl.LibrayPackageImpl#getMembers()
		 * @generated
		 */
		EClass MEMBERS = eINSTANCE.getMembers();

		/**
		 * The meta object literal for the '<em><b>Member Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MEMBERS__MEMBER_ID = eINSTANCE.getMembers_MemberId();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MEMBERS__NAME = eINSTANCE.getMembers_Name();

		/**
		 * The meta object literal for the '<em><b>Driver Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MEMBERS__DRIVER_ID = eINSTANCE.getMembers_DriverId();

		/**
		 * The meta object literal for the '{@link org.rm2pt.sample.libray.metamodel.libray.impl.ItemsModelImpl <em>Items Model</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.sample.libray.metamodel.libray.impl.ItemsModelImpl
		 * @see org.rm2pt.sample.libray.metamodel.libray.impl.LibrayPackageImpl#getItemsModel()
		 * @generated
		 */
		EClass ITEMS_MODEL = eINSTANCE.getItemsModel();

		/**
		 * The meta object literal for the '<em><b>Library</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ITEMS_MODEL__LIBRARY = eINSTANCE.getItemsModel_Library();

		/**
		 * The meta object literal for the '<em><b>Item</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ITEMS_MODEL__ITEM = eINSTANCE.getItemsModel_Item();

		/**
		 * The meta object literal for the '<em><b>Membership</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ITEMS_MODEL__MEMBERSHIP = eINSTANCE.getItemsModel_Membership();

	}

} //LibrayPackage
