/**
 */
package org.rm2pt.sample.libray.metamodel.libray;

import java.util.Date;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>books</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.books#getIsbn <em>Isbn</em>}</li>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.books#getAuthor <em>Author</em>}</li>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.books#getGenre <em>Genre</em>}</li>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.books#getPublishDate <em>Publish Date</em>}</li>
 * </ul>
 *
 * @see org.rm2pt.sample.libray.metamodel.libray.LibrayPackage#getbooks()
 * @model
 * @generated
 */
public interface books extends Item {
	/**
	 * Returns the value of the '<em><b>Isbn</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Isbn</em>' attribute.
	 * @see #setIsbn(int)
	 * @see org.rm2pt.sample.libray.metamodel.libray.LibrayPackage#getbooks_Isbn()
	 * @model
	 * @generated
	 */
	int getIsbn();

	/**
	 * Sets the value of the '{@link org.rm2pt.sample.libray.metamodel.libray.books#getIsbn <em>Isbn</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Isbn</em>' attribute.
	 * @see #getIsbn()
	 * @generated
	 */
	void setIsbn(int value);

	/**
	 * Returns the value of the '<em><b>Author</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Author</em>' attribute.
	 * @see #setAuthor(String)
	 * @see org.rm2pt.sample.libray.metamodel.libray.LibrayPackage#getbooks_Author()
	 * @model
	 * @generated
	 */
	String getAuthor();

	/**
	 * Sets the value of the '{@link org.rm2pt.sample.libray.metamodel.libray.books#getAuthor <em>Author</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Author</em>' attribute.
	 * @see #getAuthor()
	 * @generated
	 */
	void setAuthor(String value);

	/**
	 * Returns the value of the '<em><b>Genre</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Genre</em>' attribute.
	 * @see #setGenre(String)
	 * @see org.rm2pt.sample.libray.metamodel.libray.LibrayPackage#getbooks_Genre()
	 * @model
	 * @generated
	 */
	String getGenre();

	/**
	 * Sets the value of the '{@link org.rm2pt.sample.libray.metamodel.libray.books#getGenre <em>Genre</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Genre</em>' attribute.
	 * @see #getGenre()
	 * @generated
	 */
	void setGenre(String value);

	/**
	 * Returns the value of the '<em><b>Publish Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Publish Date</em>' attribute.
	 * @see #setPublishDate(Date)
	 * @see org.rm2pt.sample.libray.metamodel.libray.LibrayPackage#getbooks_PublishDate()
	 * @model
	 * @generated
	 */
	Date getPublishDate();

	/**
	 * Sets the value of the '{@link org.rm2pt.sample.libray.metamodel.libray.books#getPublishDate <em>Publish Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Publish Date</em>' attribute.
	 * @see #getPublishDate()
	 * @generated
	 */
	void setPublishDate(Date value);

} // books
