/**
 */
package org.rm2pt.sample.libray.metamodel.libray;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Membership</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.Membership#getBannedmembers <em>Bannedmembers</em>}</li>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.Membership#isMembershibStatus <em>Membershib Status</em>}</li>
 * </ul>
 *
 * @see org.rm2pt.sample.libray.metamodel.libray.LibrayPackage#getMembership()
 * @model abstract="true"
 * @generated
 */
public interface Membership extends EObject {
	/**
	 * Returns the value of the '<em><b>Bannedmembers</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Bannedmembers</em>' attribute.
	 * @see #setBannedmembers(String)
	 * @see org.rm2pt.sample.libray.metamodel.libray.LibrayPackage#getMembership_Bannedmembers()
	 * @model
	 * @generated
	 */
	String getBannedmembers();

	/**
	 * Sets the value of the '{@link org.rm2pt.sample.libray.metamodel.libray.Membership#getBannedmembers <em>Bannedmembers</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Bannedmembers</em>' attribute.
	 * @see #getBannedmembers()
	 * @generated
	 */
	void setBannedmembers(String value);

	/**
	 * Returns the value of the '<em><b>Membershib Status</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Membershib Status</em>' attribute.
	 * @see #setMembershibStatus(boolean)
	 * @see org.rm2pt.sample.libray.metamodel.libray.LibrayPackage#getMembership_MembershibStatus()
	 * @model
	 * @generated
	 */
	boolean isMembershibStatus();

	/**
	 * Sets the value of the '{@link org.rm2pt.sample.libray.metamodel.libray.Membership#isMembershibStatus <em>Membershib Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Membershib Status</em>' attribute.
	 * @see #isMembershibStatus()
	 * @generated
	 */
	void setMembershibStatus(boolean value);

} // Membership
