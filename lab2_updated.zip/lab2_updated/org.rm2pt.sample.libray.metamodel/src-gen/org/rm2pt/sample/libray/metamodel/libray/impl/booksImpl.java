/**
 */
package org.rm2pt.sample.libray.metamodel.libray.impl;

import java.util.Date;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.rm2pt.sample.libray.metamodel.libray.LibrayPackage;
import org.rm2pt.sample.libray.metamodel.libray.books;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>books</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.impl.booksImpl#getIsbn <em>Isbn</em>}</li>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.impl.booksImpl#getAuthor <em>Author</em>}</li>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.impl.booksImpl#getGenre <em>Genre</em>}</li>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.impl.booksImpl#getPublishDate <em>Publish Date</em>}</li>
 * </ul>
 *
 * @generated
 */
public class booksImpl extends ItemImpl implements books {
	/**
	 * The default value of the '{@link #getIsbn() <em>Isbn</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIsbn()
	 * @generated
	 * @ordered
	 */
	protected static final int ISBN_EDEFAULT = 0;
	/**
	 * The cached value of the '{@link #getIsbn() <em>Isbn</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIsbn()
	 * @generated
	 * @ordered
	 */
	protected int isbn = ISBN_EDEFAULT;
	/**
	 * The default value of the '{@link #getAuthor() <em>Author</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAuthor()
	 * @generated
	 * @ordered
	 */
	protected static final String AUTHOR_EDEFAULT = null;
	/**
	 * The cached value of the '{@link #getAuthor() <em>Author</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAuthor()
	 * @generated
	 * @ordered
	 */
	protected String author = AUTHOR_EDEFAULT;
	/**
	 * The default value of the '{@link #getGenre() <em>Genre</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGenre()
	 * @generated
	 * @ordered
	 */
	protected static final String GENRE_EDEFAULT = null;
	/**
	 * The cached value of the '{@link #getGenre() <em>Genre</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGenre()
	 * @generated
	 * @ordered
	 */
	protected String genre = GENRE_EDEFAULT;
	/**
	 * The default value of the '{@link #getPublishDate() <em>Publish Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPublishDate()
	 * @generated
	 * @ordered
	 */
	protected static final Date PUBLISH_DATE_EDEFAULT = null;
	/**
	 * The cached value of the '{@link #getPublishDate() <em>Publish Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPublishDate()
	 * @generated
	 * @ordered
	 */
	protected Date publishDate = PUBLISH_DATE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected booksImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return LibrayPackage.Literals.BOOKS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getIsbn() {
		return isbn;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIsbn(int newIsbn) {
		int oldIsbn = isbn;
		isbn = newIsbn;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LibrayPackage.BOOKS__ISBN, oldIsbn, isbn));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getAuthor() {
		return author;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAuthor(String newAuthor) {
		String oldAuthor = author;
		author = newAuthor;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LibrayPackage.BOOKS__AUTHOR, oldAuthor, author));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getGenre() {
		return genre;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setGenre(String newGenre) {
		String oldGenre = genre;
		genre = newGenre;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LibrayPackage.BOOKS__GENRE, oldGenre, genre));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Date getPublishDate() {
		return publishDate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPublishDate(Date newPublishDate) {
		Date oldPublishDate = publishDate;
		publishDate = newPublishDate;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LibrayPackage.BOOKS__PUBLISH_DATE, oldPublishDate,
					publishDate));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case LibrayPackage.BOOKS__ISBN:
			return getIsbn();
		case LibrayPackage.BOOKS__AUTHOR:
			return getAuthor();
		case LibrayPackage.BOOKS__GENRE:
			return getGenre();
		case LibrayPackage.BOOKS__PUBLISH_DATE:
			return getPublishDate();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case LibrayPackage.BOOKS__ISBN:
			setIsbn((Integer) newValue);
			return;
		case LibrayPackage.BOOKS__AUTHOR:
			setAuthor((String) newValue);
			return;
		case LibrayPackage.BOOKS__GENRE:
			setGenre((String) newValue);
			return;
		case LibrayPackage.BOOKS__PUBLISH_DATE:
			setPublishDate((Date) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case LibrayPackage.BOOKS__ISBN:
			setIsbn(ISBN_EDEFAULT);
			return;
		case LibrayPackage.BOOKS__AUTHOR:
			setAuthor(AUTHOR_EDEFAULT);
			return;
		case LibrayPackage.BOOKS__GENRE:
			setGenre(GENRE_EDEFAULT);
			return;
		case LibrayPackage.BOOKS__PUBLISH_DATE:
			setPublishDate(PUBLISH_DATE_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case LibrayPackage.BOOKS__ISBN:
			return isbn != ISBN_EDEFAULT;
		case LibrayPackage.BOOKS__AUTHOR:
			return AUTHOR_EDEFAULT == null ? author != null : !AUTHOR_EDEFAULT.equals(author);
		case LibrayPackage.BOOKS__GENRE:
			return GENRE_EDEFAULT == null ? genre != null : !GENRE_EDEFAULT.equals(genre);
		case LibrayPackage.BOOKS__PUBLISH_DATE:
			return PUBLISH_DATE_EDEFAULT == null ? publishDate != null : !PUBLISH_DATE_EDEFAULT.equals(publishDate);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (isbn: ");
		result.append(isbn);
		result.append(", author: ");
		result.append(author);
		result.append(", genre: ");
		result.append(genre);
		result.append(", publishDate: ");
		result.append(publishDate);
		result.append(')');
		return result.toString();
	}

} //booksImpl
