/**
 */
package org.rm2pt.sample.libray.metamodel.libray.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;
import org.rm2pt.sample.libray.metamodel.libray.LibrayPackage;
import org.rm2pt.sample.libray.metamodel.libray.Membership;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Membership</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.impl.MembershipImpl#getBannedmembers <em>Bannedmembers</em>}</li>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.impl.MembershipImpl#isMembershibStatus <em>Membershib Status</em>}</li>
 * </ul>
 *
 * @generated
 */
public abstract class MembershipImpl extends MinimalEObjectImpl.Container implements Membership {
	/**
	 * The default value of the '{@link #getBannedmembers() <em>Bannedmembers</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBannedmembers()
	 * @generated
	 * @ordered
	 */
	protected static final String BANNEDMEMBERS_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getBannedmembers() <em>Bannedmembers</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBannedmembers()
	 * @generated
	 * @ordered
	 */
	protected String bannedmembers = BANNEDMEMBERS_EDEFAULT;

	/**
	 * The default value of the '{@link #isMembershibStatus() <em>Membershib Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isMembershibStatus()
	 * @generated
	 * @ordered
	 */
	protected static final boolean MEMBERSHIB_STATUS_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isMembershibStatus() <em>Membershib Status</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isMembershibStatus()
	 * @generated
	 * @ordered
	 */
	protected boolean membershibStatus = MEMBERSHIB_STATUS_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MembershipImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return LibrayPackage.Literals.MEMBERSHIP;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getBannedmembers() {
		return bannedmembers;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setBannedmembers(String newBannedmembers) {
		String oldBannedmembers = bannedmembers;
		bannedmembers = newBannedmembers;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LibrayPackage.MEMBERSHIP__BANNEDMEMBERS,
					oldBannedmembers, bannedmembers));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isMembershibStatus() {
		return membershibStatus;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMembershibStatus(boolean newMembershibStatus) {
		boolean oldMembershibStatus = membershibStatus;
		membershibStatus = newMembershibStatus;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LibrayPackage.MEMBERSHIP__MEMBERSHIB_STATUS,
					oldMembershibStatus, membershibStatus));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case LibrayPackage.MEMBERSHIP__BANNEDMEMBERS:
			return getBannedmembers();
		case LibrayPackage.MEMBERSHIP__MEMBERSHIB_STATUS:
			return isMembershibStatus();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case LibrayPackage.MEMBERSHIP__BANNEDMEMBERS:
			setBannedmembers((String) newValue);
			return;
		case LibrayPackage.MEMBERSHIP__MEMBERSHIB_STATUS:
			setMembershibStatus((Boolean) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case LibrayPackage.MEMBERSHIP__BANNEDMEMBERS:
			setBannedmembers(BANNEDMEMBERS_EDEFAULT);
			return;
		case LibrayPackage.MEMBERSHIP__MEMBERSHIB_STATUS:
			setMembershibStatus(MEMBERSHIB_STATUS_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case LibrayPackage.MEMBERSHIP__BANNEDMEMBERS:
			return BANNEDMEMBERS_EDEFAULT == null ? bannedmembers != null
					: !BANNEDMEMBERS_EDEFAULT.equals(bannedmembers);
		case LibrayPackage.MEMBERSHIP__MEMBERSHIB_STATUS:
			return membershibStatus != MEMBERSHIB_STATUS_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (bannedmembers: ");
		result.append(bannedmembers);
		result.append(", membershibStatus: ");
		result.append(membershibStatus);
		result.append(')');
		return result.toString();
	}

} //MembershipImpl
