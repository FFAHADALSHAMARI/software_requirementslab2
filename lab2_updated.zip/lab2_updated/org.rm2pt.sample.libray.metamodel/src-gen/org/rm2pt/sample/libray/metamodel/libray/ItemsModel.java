/**
 */
package org.rm2pt.sample.libray.metamodel.libray;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Items Model</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.ItemsModel#getLibrary <em>Library</em>}</li>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.ItemsModel#getItem <em>Item</em>}</li>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.ItemsModel#getMembership <em>Membership</em>}</li>
 * </ul>
 *
 * @see org.rm2pt.sample.libray.metamodel.libray.LibrayPackage#getItemsModel()
 * @model
 * @generated
 */
public interface ItemsModel extends EObject {
	/**
	 * Returns the value of the '<em><b>Library</b></em>' containment reference list.
	 * The list contents are of type {@link org.rm2pt.sample.libray.metamodel.libray.Library}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Library</em>' containment reference list.
	 * @see org.rm2pt.sample.libray.metamodel.libray.LibrayPackage#getItemsModel_Library()
	 * @model containment="true"
	 * @generated
	 */
	EList<Library> getLibrary();

	/**
	 * Returns the value of the '<em><b>Item</b></em>' containment reference list.
	 * The list contents are of type {@link org.rm2pt.sample.libray.metamodel.libray.Item}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Item</em>' containment reference list.
	 * @see org.rm2pt.sample.libray.metamodel.libray.LibrayPackage#getItemsModel_Item()
	 * @model containment="true"
	 * @generated
	 */
	EList<Item> getItem();

	/**
	 * Returns the value of the '<em><b>Membership</b></em>' containment reference list.
	 * The list contents are of type {@link org.rm2pt.sample.libray.metamodel.libray.Membership}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Membership</em>' containment reference list.
	 * @see org.rm2pt.sample.libray.metamodel.libray.LibrayPackage#getItemsModel_Membership()
	 * @model containment="true"
	 * @generated
	 */
	EList<Membership> getMembership();

} // ItemsModel
