/**
 */
package org.rm2pt.sample.libray.metamodel.libray.impl;

import java.util.Date;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.rm2pt.sample.libray.metamodel.libray.BannedItems;
import org.rm2pt.sample.libray.metamodel.libray.LibrayPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Banned Items</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.impl.BannedItemsImpl#getBanDate <em>Ban Date</em>}</li>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.impl.BannedItemsImpl#getReason <em>Reason</em>}</li>
 * </ul>
 *
 * @generated
 */
public class BannedItemsImpl extends ItemImpl implements BannedItems {
	/**
	 * The default value of the '{@link #getBanDate() <em>Ban Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBanDate()
	 * @generated
	 * @ordered
	 */
	protected static final Date BAN_DATE_EDEFAULT = null;
	/**
	 * The cached value of the '{@link #getBanDate() <em>Ban Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBanDate()
	 * @generated
	 * @ordered
	 */
	protected Date banDate = BAN_DATE_EDEFAULT;
	/**
	 * The default value of the '{@link #getReason() <em>Reason</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReason()
	 * @generated
	 * @ordered
	 */
	protected static final String REASON_EDEFAULT = null;
	/**
	 * The cached value of the '{@link #getReason() <em>Reason</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReason()
	 * @generated
	 * @ordered
	 */
	protected String reason = REASON_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BannedItemsImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return LibrayPackage.Literals.BANNED_ITEMS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Date getBanDate() {
		return banDate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setBanDate(Date newBanDate) {
		Date oldBanDate = banDate;
		banDate = newBanDate;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LibrayPackage.BANNED_ITEMS__BAN_DATE, oldBanDate,
					banDate));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getReason() {
		return reason;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setReason(String newReason) {
		String oldReason = reason;
		reason = newReason;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LibrayPackage.BANNED_ITEMS__REASON, oldReason,
					reason));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case LibrayPackage.BANNED_ITEMS__BAN_DATE:
			return getBanDate();
		case LibrayPackage.BANNED_ITEMS__REASON:
			return getReason();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case LibrayPackage.BANNED_ITEMS__BAN_DATE:
			setBanDate((Date) newValue);
			return;
		case LibrayPackage.BANNED_ITEMS__REASON:
			setReason((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case LibrayPackage.BANNED_ITEMS__BAN_DATE:
			setBanDate(BAN_DATE_EDEFAULT);
			return;
		case LibrayPackage.BANNED_ITEMS__REASON:
			setReason(REASON_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case LibrayPackage.BANNED_ITEMS__BAN_DATE:
			return BAN_DATE_EDEFAULT == null ? banDate != null : !BAN_DATE_EDEFAULT.equals(banDate);
		case LibrayPackage.BANNED_ITEMS__REASON:
			return REASON_EDEFAULT == null ? reason != null : !REASON_EDEFAULT.equals(reason);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (banDate: ");
		result.append(banDate);
		result.append(", reason: ");
		result.append(reason);
		result.append(')');
		return result.toString();
	}

} //BannedItemsImpl
