/**
 */
package org.rm2pt.sample.libray.metamodel.libray;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Item</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.Item#getBooksavailable <em>Booksavailable</em>}</li>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.Item#getMagazinesAvailble <em>Magazines Availble</em>}</li>
 * </ul>
 *
 * @see org.rm2pt.sample.libray.metamodel.libray.LibrayPackage#getItem()
 * @model abstract="true"
 * @generated
 */
public interface Item extends EObject {
	/**
	 * Returns the value of the '<em><b>Booksavailable</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Booksavailable</em>' attribute.
	 * @see #setBooksavailable(String)
	 * @see org.rm2pt.sample.libray.metamodel.libray.LibrayPackage#getItem_Booksavailable()
	 * @model
	 * @generated
	 */
	String getBooksavailable();

	/**
	 * Sets the value of the '{@link org.rm2pt.sample.libray.metamodel.libray.Item#getBooksavailable <em>Booksavailable</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Booksavailable</em>' attribute.
	 * @see #getBooksavailable()
	 * @generated
	 */
	void setBooksavailable(String value);

	/**
	 * Returns the value of the '<em><b>Magazines Availble</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Magazines Availble</em>' attribute.
	 * @see #setMagazinesAvailble(String)
	 * @see org.rm2pt.sample.libray.metamodel.libray.LibrayPackage#getItem_MagazinesAvailble()
	 * @model
	 * @generated
	 */
	String getMagazinesAvailble();

	/**
	 * Sets the value of the '{@link org.rm2pt.sample.libray.metamodel.libray.Item#getMagazinesAvailble <em>Magazines Availble</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Magazines Availble</em>' attribute.
	 * @see #getMagazinesAvailble()
	 * @generated
	 */
	void setMagazinesAvailble(String value);

} // Item
