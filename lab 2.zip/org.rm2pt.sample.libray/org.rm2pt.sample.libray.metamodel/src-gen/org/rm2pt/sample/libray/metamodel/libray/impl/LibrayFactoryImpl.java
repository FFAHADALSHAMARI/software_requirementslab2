/**
 */
package org.rm2pt.sample.libray.metamodel.libray.impl;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

import org.rm2pt.sample.libray.metamodel.libray.*;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class LibrayFactoryImpl extends EFactoryImpl implements LibrayFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static LibrayFactory init() {
		try {
			LibrayFactory theLibrayFactory = (LibrayFactory) EPackage.Registry.INSTANCE
					.getEFactory(LibrayPackage.eNS_URI);
			if (theLibrayFactory != null) {
				return theLibrayFactory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new LibrayFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LibrayFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case LibrayPackage.LIBRARY:
			return createLibrary();
		case LibrayPackage.BANNED_ITEMS:
			return createBannedItems();
		case LibrayPackage.BOOKS:
			return createbooks();
		case LibrayPackage.MEMBERS:
			return createMembers();
		case LibrayPackage.ITEMS_MODEL:
			return createItemsModel();
		case LibrayPackage.MAGAZINES:
			return createMagazines();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Library createLibrary() {
		LibraryImpl library = new LibraryImpl();
		return library;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BannedItems createBannedItems() {
		BannedItemsImpl bannedItems = new BannedItemsImpl();
		return bannedItems;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Magazines createMagazines() {
		MagazinesImpl magazines = new MagazinesImpl();
		return magazines;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public books createbooks() {
		booksImpl books = new booksImpl();
		return books;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Members createMembers() {
		MembersImpl members = new MembersImpl();
		return members;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ItemsModel createItemsModel() {
		ItemsModelImpl itemsModel = new ItemsModelImpl();
		return itemsModel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LibrayPackage getLibrayPackage() {
		return (LibrayPackage) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static LibrayPackage getPackage() {
		return LibrayPackage.eINSTANCE;
	}

} //LibrayFactoryImpl
