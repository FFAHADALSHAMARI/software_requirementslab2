/**
 */
package org.rm2pt.sample.libray.metamodel.libray;

import java.util.Date;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Banned Items</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.BannedItems#getBanDate <em>Ban Date</em>}</li>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.BannedItems#getReason <em>Reason</em>}</li>
 * </ul>
 *
 * @see org.rm2pt.sample.libray.metamodel.libray.LibrayPackage#getBannedItems()
 * @model
 * @generated
 */
public interface BannedItems extends Item {
	/**
	 * Returns the value of the '<em><b>Ban Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ban Date</em>' attribute.
	 * @see #setBanDate(Date)
	 * @see org.rm2pt.sample.libray.metamodel.libray.LibrayPackage#getBannedItems_BanDate()
	 * @model
	 * @generated
	 */
	Date getBanDate();

	/**
	 * Sets the value of the '{@link org.rm2pt.sample.libray.metamodel.libray.BannedItems#getBanDate <em>Ban Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ban Date</em>' attribute.
	 * @see #getBanDate()
	 * @generated
	 */
	void setBanDate(Date value);

	/**
	 * Returns the value of the '<em><b>Reason</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Reason</em>' attribute.
	 * @see #setReason(String)
	 * @see org.rm2pt.sample.libray.metamodel.libray.LibrayPackage#getBannedItems_Reason()
	 * @model
	 * @generated
	 */
	String getReason();

	/**
	 * Sets the value of the '{@link org.rm2pt.sample.libray.metamodel.libray.BannedItems#getReason <em>Reason</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Reason</em>' attribute.
	 * @see #getReason()
	 * @generated
	 */
	void setReason(String value);

} // BannedItems
