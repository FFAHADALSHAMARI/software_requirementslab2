/**
 */
package org.rm2pt.sample.libray.metamodel.libray.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import org.rm2pt.sample.libray.metamodel.libray.Item;
import org.rm2pt.sample.libray.metamodel.libray.ItemsModel;
import org.rm2pt.sample.libray.metamodel.libray.Library;
import org.rm2pt.sample.libray.metamodel.libray.LibrayPackage;
import org.rm2pt.sample.libray.metamodel.libray.Membership;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Items Model</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.impl.ItemsModelImpl#getLibrary <em>Library</em>}</li>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.impl.ItemsModelImpl#getItem <em>Item</em>}</li>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.impl.ItemsModelImpl#getMembership <em>Membership</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ItemsModelImpl extends MinimalEObjectImpl.Container implements ItemsModel {
	/**
	 * The cached value of the '{@link #getLibrary() <em>Library</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLibrary()
	 * @generated
	 * @ordered
	 */
	protected EList<Library> library;

	/**
	 * The cached value of the '{@link #getItem() <em>Item</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getItem()
	 * @generated
	 * @ordered
	 */
	protected EList<Item> item;

	/**
	 * The cached value of the '{@link #getMembership() <em>Membership</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMembership()
	 * @generated
	 * @ordered
	 */
	protected EList<Membership> membership;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ItemsModelImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return LibrayPackage.Literals.ITEMS_MODEL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Library> getLibrary() {
		if (library == null) {
			library = new EObjectContainmentEList<Library>(Library.class, this, LibrayPackage.ITEMS_MODEL__LIBRARY);
		}
		return library;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Item> getItem() {
		if (item == null) {
			item = new EObjectContainmentEList<Item>(Item.class, this, LibrayPackage.ITEMS_MODEL__ITEM);
		}
		return item;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Membership> getMembership() {
		if (membership == null) {
			membership = new EObjectContainmentEList<Membership>(Membership.class, this,
					LibrayPackage.ITEMS_MODEL__MEMBERSHIP);
		}
		return membership;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case LibrayPackage.ITEMS_MODEL__LIBRARY:
			return ((InternalEList<?>) getLibrary()).basicRemove(otherEnd, msgs);
		case LibrayPackage.ITEMS_MODEL__ITEM:
			return ((InternalEList<?>) getItem()).basicRemove(otherEnd, msgs);
		case LibrayPackage.ITEMS_MODEL__MEMBERSHIP:
			return ((InternalEList<?>) getMembership()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case LibrayPackage.ITEMS_MODEL__LIBRARY:
			return getLibrary();
		case LibrayPackage.ITEMS_MODEL__ITEM:
			return getItem();
		case LibrayPackage.ITEMS_MODEL__MEMBERSHIP:
			return getMembership();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case LibrayPackage.ITEMS_MODEL__LIBRARY:
			getLibrary().clear();
			getLibrary().addAll((Collection<? extends Library>) newValue);
			return;
		case LibrayPackage.ITEMS_MODEL__ITEM:
			getItem().clear();
			getItem().addAll((Collection<? extends Item>) newValue);
			return;
		case LibrayPackage.ITEMS_MODEL__MEMBERSHIP:
			getMembership().clear();
			getMembership().addAll((Collection<? extends Membership>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case LibrayPackage.ITEMS_MODEL__LIBRARY:
			getLibrary().clear();
			return;
		case LibrayPackage.ITEMS_MODEL__ITEM:
			getItem().clear();
			return;
		case LibrayPackage.ITEMS_MODEL__MEMBERSHIP:
			getMembership().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case LibrayPackage.ITEMS_MODEL__LIBRARY:
			return library != null && !library.isEmpty();
		case LibrayPackage.ITEMS_MODEL__ITEM:
			return item != null && !item.isEmpty();
		case LibrayPackage.ITEMS_MODEL__MEMBERSHIP:
			return membership != null && !membership.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //ItemsModelImpl
