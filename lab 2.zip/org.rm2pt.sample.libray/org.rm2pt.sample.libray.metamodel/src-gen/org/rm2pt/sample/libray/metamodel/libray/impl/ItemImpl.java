/**
 */
package org.rm2pt.sample.libray.metamodel.libray.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;
import org.rm2pt.sample.libray.metamodel.libray.Item;
import org.rm2pt.sample.libray.metamodel.libray.LibrayPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Item</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.impl.ItemImpl#getBooksavailable <em>Booksavailable</em>}</li>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.impl.ItemImpl#getMagazinesAvailble <em>Magazines Availble</em>}</li>
 * </ul>
 *
 * @generated
 */
public abstract class ItemImpl extends MinimalEObjectImpl.Container implements Item {
	/**
	 * The default value of the '{@link #getBooksavailable() <em>Booksavailable</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBooksavailable()
	 * @generated
	 * @ordered
	 */
	protected static final String BOOKSAVAILABLE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getBooksavailable() <em>Booksavailable</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBooksavailable()
	 * @generated
	 * @ordered
	 */
	protected String booksavailable = BOOKSAVAILABLE_EDEFAULT;

	/**
	 * The default value of the '{@link #getMagazinesAvailble() <em>Magazines Availble</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMagazinesAvailble()
	 * @generated
	 * @ordered
	 */
	protected static final String MAGAZINES_AVAILBLE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getMagazinesAvailble() <em>Magazines Availble</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMagazinesAvailble()
	 * @generated
	 * @ordered
	 */
	protected String magazinesAvailble = MAGAZINES_AVAILBLE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ItemImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return LibrayPackage.Literals.ITEM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getBooksavailable() {
		return booksavailable;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setBooksavailable(String newBooksavailable) {
		String oldBooksavailable = booksavailable;
		booksavailable = newBooksavailable;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LibrayPackage.ITEM__BOOKSAVAILABLE, oldBooksavailable,
					booksavailable));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getMagazinesAvailble() {
		return magazinesAvailble;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMagazinesAvailble(String newMagazinesAvailble) {
		String oldMagazinesAvailble = magazinesAvailble;
		magazinesAvailble = newMagazinesAvailble;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LibrayPackage.ITEM__MAGAZINES_AVAILBLE,
					oldMagazinesAvailble, magazinesAvailble));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case LibrayPackage.ITEM__BOOKSAVAILABLE:
			return getBooksavailable();
		case LibrayPackage.ITEM__MAGAZINES_AVAILBLE:
			return getMagazinesAvailble();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case LibrayPackage.ITEM__BOOKSAVAILABLE:
			setBooksavailable((String) newValue);
			return;
		case LibrayPackage.ITEM__MAGAZINES_AVAILBLE:
			setMagazinesAvailble((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case LibrayPackage.ITEM__BOOKSAVAILABLE:
			setBooksavailable(BOOKSAVAILABLE_EDEFAULT);
			return;
		case LibrayPackage.ITEM__MAGAZINES_AVAILBLE:
			setMagazinesAvailble(MAGAZINES_AVAILBLE_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case LibrayPackage.ITEM__BOOKSAVAILABLE:
			return BOOKSAVAILABLE_EDEFAULT == null ? booksavailable != null
					: !BOOKSAVAILABLE_EDEFAULT.equals(booksavailable);
		case LibrayPackage.ITEM__MAGAZINES_AVAILBLE:
			return MAGAZINES_AVAILBLE_EDEFAULT == null ? magazinesAvailble != null
					: !MAGAZINES_AVAILBLE_EDEFAULT.equals(magazinesAvailble);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (booksavailable: ");
		result.append(booksavailable);
		result.append(", magazinesAvailble: ");
		result.append(magazinesAvailble);
		result.append(')');
		return result.toString();
	}

} //ItemImpl
